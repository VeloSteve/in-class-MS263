Data from Table 10.1 of McKillup and Dyar, Geostatistics Explained, Cambridge University Press, 2010.

Values are the weight percent of MgO present in tourmalines from three locations in Maine.
Each CSV file contains the same data in a different format.